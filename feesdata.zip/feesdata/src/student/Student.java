package student;

import db.MyConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;

public class Student {

    Connection con = MyConnection.getconnection();
    PreparedStatement ps;

    //get table max row
    public int getMax() {
        int reg_no = 0;
        Statement st;
        try {
            st = con.createStatement();
            ResultSet rs = st.executeQuery("select max(reg_no) from student");
            while (rs.next()) {
                reg_no = rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        return reg_no + 1;
    }

    //insert data into student table
    public void insert(String name, int reg_no, String dept, String gender, String date_of_birth, String father_name, String mother_name, String address, String phone_no, String academic, String total_amt, String amt_paid, String paid_date, String bal_amt) {
        String sql = "insert into student values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, reg_no);
            ps.setString(3, dept);
            ps.setString(4, gender);
            ps.setString(5, date_of_birth);
            ps.setString(6, father_name);
            ps.setString(7, mother_name);
            ps.setString(8, address);
            ps.setString(9, phone_no);
            ps.setString(10, academic);
            ps.setString(11, total_amt);
            ps.setString(12, amt_paid);
            ps.setString(13, paid_date);
            ps.setString(14, bal_amt);
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "New Student added Successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //get all the student values from database
    public void getStudentvalue(JTable table, String searchValue) {
        String sql = "select * from student where concat(name,reg_no,dept,gender,date_of_birth,father_name,mother_name,address,phone_no,academic,total_amt,amt_paid,paid_date,bal_amt)like? order by reg_no asc";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchValue + "%");
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            Object[] row;
            while (rs.next()) {
                row = new Object[14];
                row[0] = rs.getString(1);
                row[1] = rs.getInt(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getString(7);
                row[7] = rs.getString(8);
                row[8] = rs.getString(9);
                row[9] = rs.getString(10);
                row[10] = rs.getString(11);
                row[11] = rs.getString(12);
                row[12] = rs.getString(13);
                row[13] = rs.getString(14);
                model.addRow(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //update student value
    public void update(String name, int reg_no, String dept, String gender, String date_of_birth, String father_name, String mother_name, String address, String phone_no, String academic, String total_amt, String amt_paid, String paid_date, String bal_amt) {
        String sql = "update student set name=?,dept=?,gender =?,date_of_birth =?,father_name =?,mother_name=?,address=?,phone_no=?,academic=?,total_amt=?,amt_paid=?,paid_date=?,bal_amt=? where reg_no=?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, dept);
            ps.setString(3, gender);
            ps.setString(4, date_of_birth);
            ps.setString(5, father_name);
            ps.setString(6, mother_name);
            ps.setString(7, address);
            ps.setString(8, phone_no);
            ps.setString(9, academic);
            ps.setString(10, total_amt);
            ps.setString(11, amt_paid);
            ps.setString(12, paid_date);
            ps.setString(13, bal_amt);
            ps.setInt(14, reg_no);
            if (ps.executeUpdate() > 0) {
                JOptionPane.showMessageDialog(null, "Student Data Updated Successfully");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public boolean isreg_noExist(int reg_no) {
        try {
            ps = con.prepareStatement("select * from student where reg_no = ?");
            ps.setInt(1, reg_no);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    //student data delete
    public void delete(int reg_no) {
        int YesorNo = JOptionPane.showConfirmDialog(null, "Student data will be Deleted", "Student Delete", JOptionPane.OK_CANCEL_OPTION, 0);
        if (YesorNo == JOptionPane.OK_OPTION) {
            try {
                ps = con.prepareStatement("Delete from student where reg_no=?");
                ps.setInt(1, reg_no);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Student Data Deleted Successfully");

                }
            } catch (SQLException ex) {
                Logger.getLogger(Student.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}
